package com.citi.banking.interfaces;

import java.time.LocalDate;

import com.citi.banking.models.Product;

public interface Messageable{
	Product getMessage(LocalDate d1);
}