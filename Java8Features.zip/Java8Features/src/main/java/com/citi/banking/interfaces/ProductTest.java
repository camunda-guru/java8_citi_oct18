package com.citi.banking.interfaces;

import java.time.LocalDate;

import com.citi.banking.models.Product;

@FunctionalInterface
public interface ProductTest {

	LocalDate getProductDate(Product product);
}
