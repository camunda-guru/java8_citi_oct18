package com.citi.banking.Java8Features;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.BinaryOperator;
import java.util.stream.Collectors;

import com.citi.banking.interfaces.Event;
import com.citi.banking.models.Product;

public class StreamAPIDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Event.getAllProducts().stream().filter(p->p.getDop().isBefore(LocalDate.now()))
		.map(p->p.getName().toUpperCase()).sorted().forEach(System.out::println);
		
		//list stream sort collect		
		
		List<Product> sortedList =Event.getAllProducts().stream().sorted((p1,p2)->p1.getName().compareTo(p2.getName()))
		.collect(Collectors.toList());
		//find first
		Optional<Product> optionalProduct =  sortedList.stream().findFirst();		
		System.out.println(optionalProduct.isPresent());
		optionalProduct.ifPresent(x->System.out.println(x.getName()));
		
		//orElse
		
		optionalProduct =  sortedList.stream().filter(p->p.getName().startsWith("S")).findFirst();	
		optionalProduct.orElse(new Product());
	   
		Event.getAllProducts()
		.parallelStream()
		
		.filter(s -> {
		    System.out.format("filter: %s [%s]\n",
		        s.getName().length()>2, Thread.currentThread().getName());
		    return true;
		})
		.sorted((x,y)->{
			
			return x.getName().compareTo(y.getName());
		})
		.forEachOrdered(s -> System.out.format("forEach: %s [%s]\n",
			    s.getName(), Thread.currentThread().getName()));
		
		
		Integer[] trades= {45,67,89,34,56};
		BinaryOperator<Integer> adder = (a,b) -> a+b;
		 
		 
		 
		Integer aggQty = Arrays.asList(trades).stream().reduce(0,adder);
		
		System.out.print(aggQty);
		
		
	}

}
