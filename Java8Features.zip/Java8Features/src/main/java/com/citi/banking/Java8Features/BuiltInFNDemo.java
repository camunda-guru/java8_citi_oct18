package com.citi.banking.Java8Features;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import com.citi.banking.interfaces.Event;
import com.citi.banking.interfaces.ProductTest;
import com.citi.banking.interfaces.TriFunction;
import com.citi.banking.models.Product;

public class BuiltInFNDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Function Bulit In
		
		Function<Integer,Boolean> fn= (x)-> x%2==0;
		
		//invoke this Function
		
		System.out.println(fn.apply(56));
		
		
		Function<String,String> transferMessage=(indata)->{
			return "Receoved as"+indata;
		};
		
		System.out.println(transferMessage.apply("Image Transfer"));
		
		
		//BiFunction
		
		BiFunction<Product,Product,Boolean> laterProduct=(p1,p2)->{
			
			return p1.getDop().isAfter(p2.getDop());
		};
		
		System.out.println(laterProduct.apply(new Product(1,"Table",LocalDate.of(2018, 2, 22)),
				new Product(2,"Chair",LocalDate.of(2018, 4, 15))));
		
		
		//Consumer		
		Consumer<List<Product>> filterProducts=(products)->{			
			
			
			for(Product product : products)
			{
				if(product.getDop().getMonth()==Month.FEBRUARY)
				{
					System.out.println(product.getName());
				}
				
			}
			
		};
		
		filterProducts.accept(Event.getAllProducts());
		
		//Supplier
		
	    Supplier<Integer> supplier=Event::getOTP;
	    System.out.println(supplier.get());
		
	    //method references with parameters
		Function<Integer,Integer> test=Event::getParamOTP;		
		System.out.println(test.apply(100000));
	  
		
// TriFunction
		TriFunction<Integer,Integer,Integer,Integer> volume = (x,y,z) -> x*y*z;
		System.out.println(volume.apply(34, 56, 78));
		
		 
		

	}

}
