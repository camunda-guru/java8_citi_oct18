package com.citi.banking.interfaces;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.citi.banking.models.Product;

public interface Event {
	
	//default methods
	
	default String getEventName()
	{
		return "Java 8 Workshop";
	}
	
	public static List<String> getAllEvents()
	{
		List<String> eventList=new ArrayList<String>();
		eventList.add("Java8");
		eventList.add("MicroServices");
		eventList.add("ML");
		return eventList;
	}

	
	public static List<Product> getAllProducts()
	{
		List<Product> productList=new ArrayList<Product>();
		productList.add(new Product(1,"Table",LocalDate.of(2018, 2, 22)));
		productList.add(new Product(2,"Laptop",LocalDate.of(2018, 5, 22)));
		productList.add(new Product(3,"Desk",LocalDate.of(2018, 3, 15)));
		return productList;
	}
	
	public static Integer getOTP()
	{
		return new Random().nextInt(1000000);
	}
	
	public static Integer getParamOTP(int seed)
	{
		return new Random().nextInt(seed);
	}
	
	public static LocalDate getProduct(Product product)
	{
		return product.getDop();
	}
	
}
