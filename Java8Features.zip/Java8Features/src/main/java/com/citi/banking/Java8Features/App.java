package com.citi.banking.Java8Features;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.citi.banking.business.CitiEvent;
import com.citi.banking.interfaces.Event;
import com.citi.banking.interfaces.Message;
import com.citi.banking.models.Product;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	 LocalDate localDate=LocalDate.now();
        Event citiEvent=new CitiEvent();
        System.out.println(citiEvent.getEventName());
        for(String eventName : Event.getAllEvents())
        {
        	System.out.println(eventName);
        }
        
        //functional interface with param
        Message message=(info)->       	
        	 "Received as"+localDate.toString()+info;
        
       
        System.out.println(message.transferData("Image to network"));
        
        //functional interface without param
        Runnable runnable=()->{
        	System.out.println(Thread.currentThread().getName());
        };
        
        new Thread(runnable).start();
        
        Comparator<Product> comparator =(o1,o2)->
        	
        	 o1.getName().compareTo(o2.getName());
        
       
        //before sorting
        for(Product product : Event.getAllProducts())
        {
        	System.out.println(product.getName());
        }
        
        List<Product> list = Event.getAllProducts();
        list.sort(comparator);
        //Collections.sort(list, comparator);
        
      //after sorting
        for(Product product : list)
        {
        	System.out.println(product.getName());
        }
        
    }
}
