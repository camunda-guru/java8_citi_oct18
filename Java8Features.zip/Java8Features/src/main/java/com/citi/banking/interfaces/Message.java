package com.citi.banking.interfaces;

@FunctionalInterface
public interface Message {

	
	public String transferData(String x);
}
