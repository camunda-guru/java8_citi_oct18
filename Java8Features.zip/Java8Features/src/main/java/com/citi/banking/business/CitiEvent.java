package com.citi.banking.business;

import com.citi.banking.interfaces.Event;

public class CitiEvent implements Event{

	/*@Override
	public String getEventName() {
		// TODO Auto-generated method stub
		return "AI Event";
	}*/

	
}
