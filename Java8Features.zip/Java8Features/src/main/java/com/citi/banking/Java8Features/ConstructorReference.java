package com.citi.banking.Java8Features;

import java.time.LocalDate;

import com.citi.banking.interfaces.Messageable;
import com.citi.banking.models.Product;



public class ConstructorReference {
	public static void main(String[] args) {
		Messageable messageable = Product::new;
		Product product = messageable .getMessage(LocalDate.now());
		System.out.println(product.getDop().toString());
	}
}
